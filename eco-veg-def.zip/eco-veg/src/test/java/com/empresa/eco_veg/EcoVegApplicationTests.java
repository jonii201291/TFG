package com.empresa.eco_veg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoVegApplicationTests {

	@Test
	void contextLoads() {
	}

}
