package com.empresa.eco_veg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.empresa.eco_veg.repository.AnimalRepository;
import com.empresa.eco_veg.repository.ProductoRepository;
import com.empresa.eco_veg.repository.ServicioVeterinarioRepository;

@Controller
public class HomeController {
    
    @Autowired
    private AnimalRepository animalRepository;
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private ServicioVeterinarioRepository servicioVeterinarioRepository;

    // PÁGINA PRINCIPAL
    @GetMapping("/")
    public String inicio(Model model) {
        
        model.addAttribute("animales", animalRepository.findByAdoptado(false));
        model.addAttribute("productos", productoRepository.findAll());
        model.addAttribute("servicios", servicioVeterinarioRepository.findAll());
        return "index"; 
    }

    // SECCIÓN DE VETERINARIA
    @GetMapping("/veterinaria")
    public String veterinaria(Model model) {

        model.addAttribute("servicios", servicioVeterinarioRepository.findAll());
        return "veterinaria";
    }

    // SECCIÓN DE RESCATE
    @GetMapping("/rescate")
    public String rescate() {
        return "rescate";
    }

    // MUESTRA LA LISTA DE PRODUCTOS
    @GetMapping("/productos")
    public String productos(Model model) {

        model.addAttribute("productos", productoRepository.findAll());
        return "productos";
    }

    // PÁGINA DE LOGIN
    @GetMapping("/login")
    public String login() {
        return "login";
    }
}
