package com.empresa.eco_veg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//ARRANQUE DE LA APP
@SpringBootApplication
public class EcoVegApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoVegApplication.class, args);
	}

}
