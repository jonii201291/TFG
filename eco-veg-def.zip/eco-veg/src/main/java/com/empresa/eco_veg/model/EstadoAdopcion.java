package com.empresa.eco_veg.model;

public enum EstadoAdopcion {
    NO_ADOPTADO,
    PENDIENTE,
    ADOPTADO
}