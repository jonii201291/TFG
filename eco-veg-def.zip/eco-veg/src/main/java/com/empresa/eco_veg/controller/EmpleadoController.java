package com.empresa.eco_veg.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.empresa.eco_veg.dto.TablaDto;
import com.empresa.eco_veg.model.Animal;
import com.empresa.eco_veg.repository.AnimalRepository;

/**
 * EMPLEADO.
 * CRUD ANIMALES
 */
@Controller
public class EmpleadoController {

    private final AnimalRepository animalRepository;

    public EmpleadoController(AnimalRepository animalRepository) {
        this.animalRepository = animalRepository;
    }

    // PANEL DEL EMPLEADO
    @GetMapping("/empleado")
    public String panel() {
        return "empleado";
    }

    // EMPLEADO SÓLO PUEDE VER EL LISTADO DE ANIMALES
    @GetMapping("/empleado/animales")
    public String animales(Model model) {

        TablaDto tabla = new TablaDto();
        tabla.setTitulo("Animales");

        List<Map<String, Object>> filas = new ArrayList<>();

        for (Animal a : animalRepository.findAll()) {

            Map<String, Object> fila = new LinkedHashMap<>();

            fila.put("ID", a.getId());
            fila.put("Microchip", a.getMicrochip());
            fila.put("Nombre", a.getNombre());
            fila.put("Especie", a.getEspecie());
            fila.put("Raza", a.getRaza());
            fila.put("Edad", a.getEdad());
            fila.put("Descripción", a.getDescripcion());
            fila.put("Imagen", a.getImagenUrl());
            fila.put("Adoptado", a.isAdoptado());

            filas.add(fila);
        }

        tabla.setColumnas(List.of("ID", "Microchip", "Nombre", "Especie", "Raza", "Edad","Descripción", "Imagen", "Adoptado"));
        tabla.setFilas(filas);
        tabla.setNuevoUrl("/empleado/animales/nuevo");
        tabla.setEditarBaseUrl("/empleado/animales/editar");
        tabla.setEliminarBaseUrl("/empleado/animal/eliminar");
        tabla.setVolverUrl("/empleado");

        model.addAttribute("tabla", tabla);

        return "admin/tabla";
    }

    // FORMULARIO DE ALTA
    @GetMapping("/empleado/animales/nuevo")
    public String nuevoAnimal(Model model) {

        model.addAttribute("animal", new Animal());
        añadirNavegacion(model);

        return "admin/form-animal";
    }

    // FORMULARIO DE EDICIÓN
    @GetMapping("/empleado/animales/editar/{id}")
    public String editarAnimal(@PathVariable Long id, Model model) {

        model.addAttribute("animal", animalRepository.findById(id).orElseThrow());
        añadirNavegacion(model);

        return "admin/form-animal";
    }

    // GUARDAR
    @PostMapping("/empleado/animal/guardar")
    public String guardarAnimal(Animal animal) {

        animalRepository.save(animal);
        return "redirect:/empleado/animales";
    }

    // ELIMINAR
    @GetMapping("/empleado/animal/eliminar/{id}")
    public String eliminarAnimal(@PathVariable Long id) {

        animalRepository.deleteById(id);
        return "redirect:/empleado/animales";
    }

    // REUTILIZACIÓN DE URLS PARA ADMIN HACIA LA CLASE FORM-ANIMAL.HTML 
    private void añadirNavegacion(Model model) {

        model.addAttribute("accionGuardar", "/empleado/animal/guardar");
        model.addAttribute("panelUrl", "/empleado");
        model.addAttribute("listaUrl", "/empleado/animales");
    }
}
