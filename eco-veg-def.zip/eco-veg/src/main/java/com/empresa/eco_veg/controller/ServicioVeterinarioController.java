package com.empresa.eco_veg.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.empresa.eco_veg.dto.TablaDto;
import com.empresa.eco_veg.model.ServicioVeterinario;
import com.empresa.eco_veg.repository.ServicioVeterinarioRepository;

@Controller
public class ServicioVeterinarioController {

    private final ServicioVeterinarioRepository servicioVeterinarioRepository;

    public ServicioVeterinarioController(ServicioVeterinarioRepository servicioVeterinarioRepository) {
        this.servicioVeterinarioRepository = servicioVeterinarioRepository;
    }

    // FORMULARIO DE ALTA
    @GetMapping("/admin/servicios/nuevo")
    public String nuevoServicio(Model model) {

        model.addAttribute("servicioVeterinario", new ServicioVeterinario());
        return "admin/form-servicio";
    }

    // FORMULARIO DE EDICIÓN
    @GetMapping("/admin/servicioVeterinario/editar/{id}")
    public String editarServicio(@PathVariable Long id, Model model) {

        model.addAttribute("servicioVeterinario", servicioVeterinarioRepository.findById(id).orElseThrow());
        return "admin/form-servicio";
    }

    @PostMapping("/admin/servicioVeterinario/guardar")
    public String guardarServicioVeterinario(ServicioVeterinario servicio){

        servicioVeterinarioRepository.save(servicio);
        return "redirect:/admin/servicios";
    }

    //ELIMINAR POR ID
    @GetMapping("/admin/servicioVeterinario/eliminar/{id}")
    public String eliminarServicioVeterinario(@PathVariable Long id){

        servicioVeterinarioRepository.deleteById(id);
        return "redirect:/admin/servicios";
    }

    //MOSTRAR EN TABLA
    @GetMapping("/admin/servicios")
    public String servicios(Model model) {

        TablaDto tabla = new TablaDto();

        tabla.setTitulo("Servicios");

        List<Map<String,Object>> filas = new ArrayList<>();

        for (ServicioVeterinario a : servicioVeterinarioRepository.findAll()) {

            Map<String,Object> fila = new LinkedHashMap<>();

            fila.put("ID", a.getId());
            fila.put("Servicio", a.getServicio());
            fila.put("Descripcion", a.getDescripcion());
            fila.put("Precio", a.getPrecio());
            fila.put("Imagen", a.getImagenUrl());

            filas.add(fila);
        }

        tabla.setColumnas(List.of("ID","Servicio","Descripcion","Precio","Imagen"));
        tabla.setFilas(filas);
        tabla.setNuevoUrl("/admin/servicios/nuevo");
        tabla.setEditarBaseUrl("/admin/servicioVeterinario/editar");
        tabla.setEliminarBaseUrl("/admin/servicioVeterinario/eliminar");

        model.addAttribute("tabla", tabla);

        return "admin/tabla";
    }
}
