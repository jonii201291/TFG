package com.empresa.eco_veg.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Animal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long microchip;
    private String nombre;
    private String especie;
    private String raza;
    private int edad;
    private String descripcion;

    @Column(name = "imagen_url")
    private String imagenUrl;
    
    private boolean adoptado;

    @OneToMany(mappedBy = "animal", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<Adopcion> adopciones;

    public Animal() {
        this.adoptado = false;
    }

    public Animal(String nombre, Long microchip, String especie, String raza, int edad,
                  String descripcion, String imagenUrl, boolean adoptado) {
        this.microchip = microchip;            
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
        this.descripcion = descripcion;
        this.imagenUrl = imagenUrl;
        this.adoptado = adoptado;
    }

    public Long getId() {return id;}
    public void setId(Long id) {this.id = id;}

    public Long getMicrochip() {return microchip;}
    public void setMicrochip(Long microchip) {this.microchip = microchip;}

    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}

    public String getEspecie() {return especie;}
    public void setEspecie(String especie) {this.especie = especie;}

    public String getRaza() {return raza;}
    public void setRaza(String raza) {this.raza = raza;}

    public int getEdad() {return edad;}
    public void setEdad(int edad) {this.edad = edad;}

    public String getDescripcion() {return descripcion;}
    public void setDescripcion(String descripcion) {this.descripcion = descripcion;}

    public String getImagenUrl() {return imagenUrl;}
    public void setImagenUrl(String imagenUrl) {this.imagenUrl = imagenUrl;}

    public boolean isAdoptado() {return adoptado;}
    public void setAdoptado(boolean adoptado) {this.adoptado = adoptado;}

    public List<Adopcion> getAdopciones() {return adopciones;}
    public void setAdopciones(List<Adopcion> adopciones) {this.adopciones = adopciones;}

    @Override
    public String toString() {
        return "Animal{" +
                "id=" + id +
                ", microchip='" + microchip + '\'' +
                ", nombre='" + nombre + '\'' +
                ", especie='" + especie + '\'' +
                ", raza='" + raza + '\'' +
                ", edad=" + edad +
                ", descripcion='" + descripcion + '\'' +
                ", imagenUrl='" + imagenUrl + '\'' +
                ", adoptado=" + adoptado +
                '}';
    }
}