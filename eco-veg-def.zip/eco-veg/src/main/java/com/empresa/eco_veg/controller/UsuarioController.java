package com.empresa.eco_veg.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.empresa.eco_veg.dto.TablaDto;
import com.empresa.eco_veg.model.Usuario;
import com.empresa.eco_veg.repository.UsuarioRepository;

/**
 * USUARIO ADMIN
 * PUEDE VER LOS USUARIOS Y HACER CRUD DE EMPLEADOS
 */
@Controller
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // LISTADO DE USUARIOS
    @GetMapping("/admin/usuarios")
    public String usuarios(Model model) {

        TablaDto tabla = new TablaDto();
        tabla.setTitulo("Usuarios");

        List<Map<String, Object>> filas = new ArrayList<>();

        for (Usuario u : usuarioRepository.findAll()) {

            Map<String, Object> fila = new LinkedHashMap<>();

            fila.put("ID", u.getId());
            fila.put("Username", u.getUsername());
            fila.put("Nombre", u.getNombre());
            fila.put("Apellidos", u.getApellidos());
            fila.put("Email", u.getEmail());
            fila.put("Teléfono", u.getTelefono());
            fila.put("Rol", u.getRol());

            filas.add(fila);
        }

        tabla.setColumnas(List.of("ID", "Username", "Nombre", "Apellidos", "Email", "Teléfono", "Rol"));
        tabla.setFilas(filas);
        tabla.setNuevoUrl("/admin/usuarios/nuevo");
        tabla.setVolverUrl("/admin");

        model.addAttribute("tabla", tabla);

        return "admin/tabla";
    }

    // FORMULARIO DE ALTA DE EMPLEADO
    @GetMapping("/admin/usuarios/nuevo")
    public String nuevoEmpleado(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "admin/form-empleado";
    }

    // AÑADIR EMPLEADO
    @PostMapping("/admin/usuario/guardar")
    public String guardarEmpleado(@ModelAttribute Usuario usuario, Model model) {

        // SIN DUPLICADOS
        if (usuario.getUsername() != null
                && usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            model.addAttribute("error", "Ese nombre de usuario ya está en uso.");
            return "admin/form-empleado";
        }
        if (usuario.getEmail() != null 
                && !usuario.getEmail().isBlank()
                && usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            model.addAttribute("error", "Ese correo electrónico ya está registrado.");
            return "admin/form-empleado";
        }

        usuario.setRol("EMPLEADO");

        //CIFRADO DE CONTRASEÑA
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuarioRepository.save(usuario);

        return "redirect:/admin/usuarios";
    }
}
