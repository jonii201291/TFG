package com.empresa.eco_veg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.eco_veg.model.Animal;
public interface AnimalRepository extends JpaRepository<Animal, Long> {
    
    List<Animal> findByAdoptado(boolean adoptado);

}