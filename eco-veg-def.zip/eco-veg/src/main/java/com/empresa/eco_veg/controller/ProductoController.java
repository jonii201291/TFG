package com.empresa.eco_veg.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.empresa.eco_veg.dto.TablaDto;
import com.empresa.eco_veg.model.Producto;
import com.empresa.eco_veg.repository.ProductoRepository;

@Controller
public class ProductoController {

    private final ProductoRepository productoRepository;

    public ProductoController(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }
    
    @GetMapping("/admin/productos")
    public String productos(Model model) {

        TablaDto tabla = new TablaDto();

        tabla.setTitulo("Productos");

        List<Map<String,Object>> filas = new ArrayList<>();

        for (Producto a : productoRepository.findAll()) {

            Map<String,Object> fila = new LinkedHashMap<>();

            fila.put("ID", a.getId());
            fila.put("Nombre", a.getNombre());
            fila.put("Descripción", a.getDescripcion());
            fila.put("Precio", a.getPrecio());
            fila.put("Imagen", a.getImagenUrl());

            filas.add(fila);
        }

        tabla.setColumnas(
            List.of("ID","Nombre","Descripción","Precio","Imagen")
        );

        tabla.setFilas(filas);
        tabla.setNuevoUrl("/admin/productos/nuevo");
        tabla.setEditarBaseUrl("/admin/producto/editar");
        tabla.setEliminarBaseUrl("/admin/producto/eliminar");

        model.addAttribute("tabla", tabla);
        return "admin/tabla";
    }

    // FORMULARIO DE ALTA
    @GetMapping("/admin/productos/nuevo")
    public String nuevoProducto(Model model) {

        model.addAttribute("producto", new Producto());
        return "admin/form-producto";
    }

    // FORMULARIO DE EDICIÓN
    @GetMapping("/admin/producto/editar/{id}")
    public String editarProducto(@PathVariable Long id, Model model) {

        model.addAttribute("producto", productoRepository.findById(id).orElseThrow());
        return "admin/form-producto";
    }

    //AÑADIR
    @PostMapping("/admin/producto/guardar")
    public String guardarProducto(Producto producto){

        productoRepository.save(producto);
        return "redirect:/admin/productos";
    }

    //BORRAR POR ID
    @GetMapping("/admin/producto/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id){

        productoRepository.deleteById(id);
        return "redirect:/admin/productos";
    }
}
