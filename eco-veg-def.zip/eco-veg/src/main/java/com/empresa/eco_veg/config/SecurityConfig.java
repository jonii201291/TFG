package com.empresa.eco_veg.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http.csrf(csrf -> csrf.disable()).authorizeHttpRequests(auth -> auth.requestMatchers(
            "/",
            "/login",
            "/adopciones",
            "/veterinaria",
            "/rescate",
            "/productos",
            "/registro",
            "/css/**",
            "/js/**",
            "/images/**"
        ).permitAll()
        
        // SSOLICITAR ADOPCIONES, SÓLO LOGUEADOS
        .requestMatchers("/formulario-adopcion", "/enviar-adopcion", "/mis-adopciones").hasRole("CLIENTE")
        
        // ZONA DEL EMPLEADO
        .requestMatchers("/empleado", "/empleado/**").hasAnyRole("ADMIN", "EMPLEADO")
        
        // ZONA ADMIN
        .requestMatchers("/admin", "/admin/**").hasRole("ADMIN")
        .anyRequest().permitAll())
        .formLogin(form -> form.loginPage("/login")
        
        // CUADRAR LOS ROLES
        .successHandler((request, response, authentication) -> {
                boolean isAdmin = authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
                boolean isEmpleado = authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_EMPLEADO"));

                response.sendRedirect(isAdmin ? "/admin" : (isEmpleado ? "/empleado" : "/"));
            }).permitAll()).logout(logout -> logout.logoutSuccessUrl("/").permitAll());
        
        return http.build();
    }
}