package com.empresa.eco_veg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.eco_veg.model.Adopcion;
import com.empresa.eco_veg.model.EstadoAdopcion;

public interface AdopcionRepository extends JpaRepository<Adopcion, Long> {
    List<Adopcion> findByEstado(EstadoAdopcion estado);

    // Solicitudes de un usuario (para "Mis adopciones"), más recientes primero
    List<Adopcion> findByUsuario_IdOrderByIdDesc(Long usuarioId);

    // Evitar que un usuario duplique la solicitud del mismo animal
    boolean existsByUsuario_IdAndAnimal_Id(Long usuarioId, Long animalId);
}