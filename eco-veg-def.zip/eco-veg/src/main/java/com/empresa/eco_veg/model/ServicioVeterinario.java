package com.empresa.eco_veg.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "veterinario")
public class ServicioVeterinario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String servicio;
    private String descripcion;
    private double precio;

    @Column(name = "imagen_url")
    private String imagenUrl;

    public ServicioVeterinario() {
    }

    public ServicioVeterinario(String servicio, String descripcion, double precio, String imagenUrl) {
        this.servicio = servicio;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagenUrl = imagenUrl;
    }

    public Long getId() {return id;}
    public void setId(Long id) {this.id = id;}

    public String getServicio() {return servicio;}
    public void setServicio(String servicio) {this.servicio = servicio;}

    public String getDescripcion() {return descripcion;}
    public void setDescripcion(String descripcion) {this.descripcion = descripcion;}

    public double getPrecio() {return precio;}
    public void setPrecio(double precio) {this.precio = precio;}

    public String getImagenUrl() {return imagenUrl;}
    public void setImagenUrl(String imagenUrl) {this.imagenUrl = imagenUrl;}
}