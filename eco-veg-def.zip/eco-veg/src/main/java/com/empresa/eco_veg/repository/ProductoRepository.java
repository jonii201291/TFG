package com.empresa.eco_veg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.eco_veg.model.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    
    List<Producto> findByNombre(String nombre);

    List<Producto> findByPrecioLessThan(Double precio);
    
    List<Producto> findByPrecioGreaterThan(Double precio);

    List<Producto> findByNombreContaining(String texto);
}