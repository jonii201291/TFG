package com.empresa.eco_veg.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.empresa.eco_veg.model.Usuario;
import com.empresa.eco_veg.repository.UsuarioRepository;

/**
 * INICIALIZA LA BBDD
 *  AL PRINCIPIO CREA ADMIN Y EMPLEADO AL INICIALIZAR AUTOMÁTICAMNETE 
 *  ENCRIPTA LAS CONTRASEÑAS
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        // SE CREARON POR PRIMERA VEZ POR DEFECTO PARA HACER TESTEO MÁS RÁPIDO
        crearSiNoExiste("admin", "1234", "Administrador", "ADMIN");
        crearSiNoExiste("empleado", "1234", "Empleado", "EMPLEADO");

        // ENCRIPTAR CONTRASEÑAS
        for (Usuario u : usuarioRepository.findAll()) {
            String pass = u.getPassword();
            if (pass != null && !pass.startsWith("$2")) {
                u.setPassword(passwordEncoder.encode(pass));
                usuarioRepository.save(u);
            }
        }
    }

    private void crearSiNoExiste(String username, String passwordPlano, String nombre, String rol) {
        if (usuarioRepository.findByUsername(username).isEmpty()) {

            Usuario u = new Usuario();
            
            u.setUsername(username);
            u.setPassword(passwordEncoder.encode(passwordPlano));
            u.setNombre(nombre);
            u.setRol(rol);
            usuarioRepository.save(u);
        }
    }
}
