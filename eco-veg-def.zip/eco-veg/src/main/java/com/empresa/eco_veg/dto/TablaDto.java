package com.empresa.eco_veg.dto;

import java.util.List;
import java.util.Map;

// PLANTILLA TABLAS
public class TablaDto {

    private String titulo;

    private List<String> columnas;

    private List<Map<String,Object>> filas;

    //URL OPCIONALES, CON NULL, NO APARECEN
    private String nuevoUrl;
    private String editarBaseUrl;
    private String eliminarBaseUrl;

    // VUELVE A LA TABLA (CON NULL LA PLANTILLA USA LA VISUAL DE ADMIN)
    private String volverUrl;

    public TablaDto() {}

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public List<String> getColumnas() {
        return columnas;
    }

    public void setColumnas(List<String> columnas) {
        this.columnas = columnas;
    }

    public List<Map<String, Object>> getFilas() {
        return filas;
    }

    public void setFilas(List<Map<String, Object>> filas) {
        this.filas = filas;
    }

    public String getNuevoUrl() {
        return nuevoUrl;
    }

    public void setNuevoUrl(String nuevoUrl) {
        this.nuevoUrl = nuevoUrl;
    }

    public String getEditarBaseUrl() {
        return editarBaseUrl;
    }

    public void setEditarBaseUrl(String editarBaseUrl) {
        this.editarBaseUrl = editarBaseUrl;
    }

    public String getEliminarBaseUrl() {
        return eliminarBaseUrl;
    }

    public void setEliminarBaseUrl(String eliminarBaseUrl) {
        this.eliminarBaseUrl = eliminarBaseUrl;
    }

    public String getVolverUrl() {
        return volverUrl;
    }

    public void setVolverUrl(String volverUrl) {
        this.volverUrl = volverUrl;
    }
}