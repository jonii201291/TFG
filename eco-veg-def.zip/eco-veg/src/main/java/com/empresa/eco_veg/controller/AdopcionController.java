package com.empresa.eco_veg.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.empresa.eco_veg.dto.TablaDto;
import com.empresa.eco_veg.model.Adopcion;
import com.empresa.eco_veg.model.Animal;
import com.empresa.eco_veg.model.EstadoAdopcion;
import com.empresa.eco_veg.model.Usuario;
import com.empresa.eco_veg.repository.AdopcionRepository;
import com.empresa.eco_veg.repository.AnimalRepository;
import com.empresa.eco_veg.repository.UsuarioRepository;

@Controller
public class AdopcionController {

    private final AnimalRepository animalRepository;
    private final AdopcionRepository adopcionRepository;
    private final UsuarioRepository usuarioRepository;

    public AdopcionController(AnimalRepository animalRepository, AdopcionRepository adopcionRepository, UsuarioRepository usuarioRepository) {
        this.animalRepository = animalRepository;
        this.adopcionRepository = adopcionRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // MOSTRAR EL FORMULARIO DE ADOPCIÓN
    @GetMapping("/formulario-adopcion")
    public String formulario(@RequestParam Long animalId, Model model){

        Animal animal = animalRepository.findById(animalId).orElseThrow();
        model.addAttribute("animal", animal);
        model.addAttribute("animalId", animalId);
        return "formulario-adopcion";
    }

    // ENVIAR SOLICITUD DE ADOPCIÓN
    @PostMapping("/enviar-adopcion")
    public String guardarAdopcion(
            @RequestParam String motivo,
            @RequestParam String experiencia,
            @RequestParam Long animalId,
            Principal principal,
            RedirectAttributes redirectAttributes
    ){
    
        Usuario usuario = usuarioRepository.findByUsername(principal.getName()).orElse(null);
        if (usuario == null) {

            redirectAttributes.addFlashAttribute("mensaje", "Debes iniciar sesión para adoptar.");
            return "redirect:/login";
        }

        Animal animal = animalRepository.findById(animalId).orElse(null);
        if (animal == null) {

            redirectAttributes.addFlashAttribute("mensaje", "Animal no encontrado.");
            return "redirect:/adopciones";
        }
        if (animal.isAdoptado()) {

            redirectAttributes.addFlashAttribute("mensaje", "Este animal ya está adoptado.");
            return "redirect:/adopciones";
        }

        // EVITAR DUPLICADOS
        if (adopcionRepository.existsByUsuario_IdAndAnimal_Id(usuario.getId(), animalId)) {

            redirectAttributes.addFlashAttribute("mensaje", "Ya has solicitado la adopción de este animal.");
            return "redirect:/mis-adopciones";
        }

        Adopcion adopcion = new Adopcion();
        adopcion.setUsuario(usuario);
        adopcion.setAnimal(animal);
        adopcion.setMotivo(motivo);
        adopcion.setExperiencia(experiencia);
        adopcionRepository.save(adopcion);

        redirectAttributes.addFlashAttribute("mensaje", "Solicitud enviada. Está en espera de aprobación.");
        return "redirect:/mis-adopciones";
    }

    // MIS ADOPCIONES (SOLO CLIENTE)
    @GetMapping("/mis-adopciones")
    public String misAdopciones(Principal principal, Model model) {
        Usuario usuario = usuarioRepository.findByUsername(principal.getName()).orElse(null);
        List<Adopcion> adopciones = usuario == null
                ? List.of()
                : adopcionRepository.findByUsuario_IdOrderByIdDesc(usuario.getId());
        model.addAttribute("adopciones", adopciones);
        return "mis-adopciones";
    }

    // ADMIN APRUEBA LAS ADOPCIONES
    @PostMapping("/admin/aprobar-adopcion")
    public String aprobarAdopcion(
            @RequestParam Long adopcionId,
            RedirectAttributes redirectAttributes
    ){
        Adopcion adopcion = adopcionRepository.findById(adopcionId).orElse(null);

        if (adopcion == null) {
            redirectAttributes.addFlashAttribute("mensaje", "Adopción no encontrada");
            return "redirect:/admin/adopciones";
        }

        Animal animal = adopcion.getAnimal();
        animal.setAdoptado(true);
        animalRepository.save(animal);

        adopcion.setEstado(EstadoAdopcion.ADOPTADO);
        adopcionRepository.save(adopcion);

        redirectAttributes.addFlashAttribute("mensaje", "Adopción aprobada correctamente");
        return "redirect:/admin/adopciones";
    }

    // LISTAR EN TABLA DINÁMICA
    @GetMapping("/admin/adopciones")
    public String animales(Model model) {
        TablaDto tabla = new TablaDto();
        tabla.setTitulo("Solicitudes de Adopción");

        List<Map<String, Object>> filas = new ArrayList<>();

        for (Adopcion a : adopcionRepository.findAll()) {
            Map<String, Object> fila = new LinkedHashMap<>();

            fila.put("ID Solicitud", a.getId());
            fila.put("Fecha", a.getFechaSolicitud() != null ? a.getFechaSolicitud() : "Sin fecha");
            fila.put("Estado", a.getEstado() != null ? a.getEstado().toString() : "PENDIENTE");
            fila.put("Motivo", a.getMotivo() != null ? a.getMotivo() : "-");

            if (a.getUsuario() != null) {
                String nombreCompleto = a.getUsuario().getNombre() != null ? a.getUsuario().getNombre() : "";
                
                if (a.getUsuario().getApellidos() != null) {
                    nombreCompleto += " " + a.getUsuario().getApellidos();
                }
                
                fila.put("Adoptante", nombreCompleto.isBlank() ? "Sin nombre" : nombreCompleto);
                fila.put("Teléfono", a.getUsuario().getTelefono() != null ? a.getUsuario().getTelefono() : "-");
                fila.put("Email", a.getUsuario().getEmail() != null ? a.getUsuario().getEmail() : "-");
            } else {
                fila.put("Adoptante", "Usuario Corrupto / Eliminado");
                fila.put("Teléfono", "-");
                fila.put("Email", "-");
            }

            if (a.getAnimal() != null) {
                fila.put("Mascota", a.getAnimal().getNombre() != null ? a.getAnimal().getNombre() : "Sin nombre");
                fila.put("Microchip", a.getAnimal().getMicrochip() != null ? a.getAnimal().getMicrochip() : "-");
            } else {
                fila.put("Mascota", "Animal Eliminado");
                fila.put("Microchip", "-");
            }

            filas.add(fila);
        }

        tabla.setColumnas(
                List.of("ID Solicitud", "Fecha", "Estado", "Adoptante", "Teléfono", "Email", "Mascota", "Microchip", "Motivo")
        );

        tabla.setFilas(filas);
        model.addAttribute("tabla", tabla);

        return "admin/tabla";
    }
}
