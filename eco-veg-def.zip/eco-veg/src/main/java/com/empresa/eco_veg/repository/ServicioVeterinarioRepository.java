package com.empresa.eco_veg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.eco_veg.model.ServicioVeterinario;

public interface ServicioVeterinarioRepository extends JpaRepository<ServicioVeterinario, Long> {

    List<ServicioVeterinario> findByServicio(String nombre);

    List<ServicioVeterinario> findByServicioContaining(String texto);}