package com.empresa.eco_veg.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.empresa.eco_veg.dto.TablaDto;
import com.empresa.eco_veg.model.Animal;
import com.empresa.eco_veg.repository.AnimalRepository;

@Controller
public class AnimalController {

    private final AnimalRepository animalRepository;
    
    public AnimalController(AnimalRepository animalRepository) {
        this.animalRepository = animalRepository;
    }
 
    // LISTA DE ANIMALES
    @GetMapping("/animales")
    public String verAnimales(Model model) {

        model.addAttribute( "animales", animalRepository.findAll());
        return "animales";
    }

    // TABLA
    @GetMapping("/admin/animales")
    public String animales(Model model) {

        TablaDto tabla = new TablaDto();
        tabla.setTitulo("Animales");

        List<Map<String, Object>> filas = new ArrayList<>();

        for (Animal a : animalRepository.findAll()) {

            Map<String, Object> fila = new LinkedHashMap<>();

            fila.put("ID", a.getId());
            fila.put("Microchip", a.getMicrochip());
            fila.put("Nombre", a.getNombre());
            fila.put("Especie", a.getEspecie());
            fila.put("Raza", a.getRaza());
            fila.put("Edad", a.getEdad());
            fila.put("Descripción", a.getDescripcion());
            fila.put("Imagen", a.getImagenUrl());
            fila.put("Adoptado", a.isAdoptado());

            filas.add(fila);
        }

        tabla.setColumnas( List.of("ID", "Microchip", "Nombre", "Especie", "Raza", "Edad", "Descripción", "Imagen", "Adoptado"));
        tabla.setFilas(filas);
        tabla.setNuevoUrl("/admin/animales/nuevo");
        tabla.setEditarBaseUrl("/admin/animales/editar");
        tabla.setEliminarBaseUrl("/admin/animal/eliminar");

        model.addAttribute("tabla", tabla);
        return "admin/tabla";
    }

    // FORMULARIO DE ALTA
    @GetMapping("/admin/animales/nuevo")
    public String nuevoAnimal(Model model) {

        model.addAttribute("animal", new Animal());
        añadirNavegacion(model);

        return "admin/form-animal";
    }

    // ANIMALES ADOPTADOS
    @GetMapping("/admin/animales-adoptados")
    public String animalesAdoptados(Model model) {

        model.addAttribute( "animales", animalRepository.findByAdoptado(true));
        return "admin-animales";
    }

    // ANIMALES NO ADOPTADOS
    @GetMapping("/admin/animales-disponibles")
    public String animalesDisponibles(Model model) {

        model.addAttribute( "animales",animalRepository.findByAdoptado(false));
        return "admin-animales";
    }

    // AÑADIR
    @PostMapping("/admin/animal/guardar")
    public String introducirAnimal(Animal animal) {

        animalRepository.save(animal);
        return "redirect:/admin/animales";
    }

    // EDITAR
    @GetMapping("/admin/animales/editar/{id}")
    public String editarAnimal(@PathVariable Long id, Model model) {

        Animal animal = animalRepository.findById(id).orElseThrow();

        model.addAttribute("animal", animal);
        añadirNavegacion(model);

        return "admin/form-animal";
    }

    // REUTILIZACIÓN DE URLS PARA ADMIN HACIA LA CLASE FORM-ANIMAL.HTML 
    private void añadirNavegacion(Model model) {

        model.addAttribute("accionGuardar", "/admin/animal/guardar");
        model.addAttribute("panelUrl", "/admin");
        model.addAttribute("listaUrl", "/admin/animales");
    }

    @PostMapping("/admin/animales/editar")
    public String guardarAnimal(Animal animal) {

        animalRepository.save(animal);
        return "redirect:/admin/animales";
    }

    // ELIMINAR ANIMAL
    // OJO CON LAS CLAVES FORÁNEAS
    @GetMapping("/admin/animal/eliminar/{id}")
    public String eliminarAnimal(@PathVariable Long id) {

        animalRepository.deleteById(id);
        return "redirect:/admin/animales";
    }

    //MUESTRA ANIMALES NO ADOPTADOS
    @GetMapping("/adopciones")
    public String catalogoPublicoAdopciones(Model model,org.springframework.security.core.Authentication auth) {
                                               
        boolean logueado = auth != null && auth.isAuthenticated()
                && !(auth instanceof org.springframework.security.authentication.AnonymousAuthenticationToken);

        // SÓLO CLIENTES PUEDEN ADOPTAR
        boolean esCliente = logueado && auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_CLIENTE"));

        model.addAttribute("logueado", logueado);
        model.addAttribute("esCliente", esCliente);

        if (logueado) {
            model.addAttribute("animales", animalRepository.findByAdoptado(false));
        }

        return "adopciones";
    }

}