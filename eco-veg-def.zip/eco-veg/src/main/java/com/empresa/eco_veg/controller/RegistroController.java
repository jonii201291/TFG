package com.empresa.eco_veg.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.empresa.eco_veg.model.Usuario;
import com.empresa.eco_veg.repository.UsuarioRepository;

/**
 * LOGIN CLIENTES
 */
@Controller
public class RegistroController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public RegistroController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    //REGISTRO
    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        
        model.addAttribute("usuario", new Usuario());
        return "registro";
    }

    // ACCESO
    @PostMapping("/registro")
    public String registrar(@ModelAttribute Usuario usuario, Model model) {

        // VER SI HAY DUPLICADOS
        if (usuario.getUsername() != null
                && usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            model.addAttribute("error", "Ese nombre de usuario ya está en uso.");
            return "registro";
        }
        if (usuario.getEmail() != null
                && usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            model.addAttribute("error", "Ese correo electrónico ya está registrado.");
            return "registro";
        }

        // FORZAR USUARIO Y CIFRAR CONTRASEÑA
        usuario.setRol("CLIENTE");
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuarioRepository.save(usuario);

        return "redirect:/login?registrado";
    }
}
