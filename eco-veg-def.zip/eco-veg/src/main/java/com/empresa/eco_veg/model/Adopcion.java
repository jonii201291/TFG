package com.empresa.eco_veg.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Adopcion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // CLAVE FORÁNEA 1
    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    // CLAVE FORÁNEA 2
    @ManyToOne
    @JoinColumn(name = "animal_id", nullable = false)
    private Animal animal;
    private String motivo;
    private String experiencia;
    private LocalDate fechaSolicitud;

    @Enumerated(EnumType.STRING)
    private EstadoAdopcion estado;

    public Adopcion() {
        this.fechaSolicitud = LocalDate.now();
        this.estado = EstadoAdopcion.PENDIENTE; // Asumiendo que tienes este enum
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public Animal getAnimal() { return animal; }
    public void setAnimal(Animal animal) { this.animal = animal; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public String getExperiencia() { return experiencia; }
    public void setExperiencia(String experiencia) { this.experiencia = experiencia; }

    public LocalDate getFechaSolicitud() { return fechaSolicitud; }
    public void setFechaSolicitud(LocalDate fechaSolicitud) { this.fechaSolicitud = fechaSolicitud; }

    public EstadoAdopcion getEstado() { return estado; }
    public void setEstado(EstadoAdopcion estado) { this.estado = estado; }
}
